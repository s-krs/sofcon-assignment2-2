-- CREATE DATABASE `SCSpring`;
USE SCSpring;

DROP TABLE IF EXISTS `books`; 
CREATE TABLE `books` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `location` varchar(255) NOT NULL,
  `author` varchar(255) NOT NULL,
  `publisher` varchar(255) NOT NULL,
  `yearpublished` varchar(4) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `books` VALUES (1, 'Book 1', 'Andaman and Nicobar Islands', 'Author 1', 'Publisher 1', '2001');
INSERT INTO `books` VALUES (2, 'Book 2', 'Naypiydaw, Myanmar', 'Author 2', 'Publisher 2', '2002');
