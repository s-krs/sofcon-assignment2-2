package com.crudapp;

import java.util.List;
import java.util.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class AppController {
 
    @Autowired
    private BooksService service;
    
    @RequestMapping("/")
    public String viewHomePage(Model model) {
    	List<Books> listBooks = service.listAll();
    	model.addAttribute("listBooks", listBooks);
    	
    	return "index";
    }
    
    @RequestMapping("/new")
    public String showNewProductPage(Model model) {
        Books books = new Books();
        model.addAttribute("books", books);
         
        return "newbooks";
    }
    
    @RequestMapping(value = "/save", method = RequestMethod.POST)
    public String saveBooks(@ModelAttribute("books") Books books) {
        service.save(books);
         
        return "redirect:/";
    }
    
    @RequestMapping("/edit/{id}")
    public ModelAndView showEditProductPage(@PathVariable(name = "id") int id) {
        ModelAndView mav = new ModelAndView("editbooks");
        Books books = service.get(id);
        mav.addObject("books", books);
         
        return mav;
    }
    
    @RequestMapping("/delete/{id}")
    public String deleteProduct(@PathVariable(name = "id") int id) {
        service.delete(id);
        return "redirect:/";       
    }
}