package com.crudapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SofConSpring3Application {

	public static void main(String[] args) {
		SpringApplication.run(SofConSpring3Application.class, args);
	}

}
