package com.crudapp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
//import javax.persistence.Table;
import javax.persistence.Table;



@Entity
@Table(name = "books")
public class Books {
	private int id;
	@Column(name = "name")
	private String bookName;
	@Column(name = "location")
	private String bookLocation;
	@Column(name = "author")
	private String author;
	@Column(name = "publisher")
	private String publisher;
//	@Column(name = "yearpublished")
	private String yearPublished;
	
	protected Books() {}
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	public int getId() {
		return id;
	}
	
	public void setId(int bookId) {
		this.id = bookId;
	}
	
	public String getName() {
		return bookName;
	}
	
	public void setName(String bookName) {
		this.bookName = bookName;
	}
	
	public String getLocation() {
		return bookLocation;
	}
	
	public void setLocation(String bookLocation) {
		this.bookLocation = bookLocation;
	}
	
	public String getAuthor() {
		return author;
	}
	
	public void setAuthor(String author) {
		this.author = author;
	}
	
	public String getPublisher() {
		return publisher;
	}
	
	public void setPublisher(String publisher) {
		this.publisher = publisher;
	}
	
	@Column(name = "yearpublished")
	public String getYearPublished() {
		return yearPublished;
	}
	
	public void setYearPublished(String yearPublished) {
		this.yearPublished = yearPublished;
	}
}
