package com.crudapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SofConSpring3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
